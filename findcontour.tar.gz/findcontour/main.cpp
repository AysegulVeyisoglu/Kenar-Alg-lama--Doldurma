#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "iostream"

using namespace cv;
using namespace std;
std::vector<Point> points;
int sayac = 0;

void onMouse(int evt, int x, int y, int flags, void *param) {
    if (evt == CV_EVENT_FLAG_LBUTTON) {

        std::vector<cv::Point> *ptPtr = (std::vector<cv::Point> *) param;
        ptPtr->push_back(cv::Point(x, y));
        cout << points[sayac] << endl;
        sayac++;

    }
}

int main() {

    Mat image;
    image = imread("image.jpg", 1);
    namedWindow("Original", WINDOW_AUTOSIZE);
    imshow("Original", image);

    Mat gray, _img;
    cvtColor(image, gray, CV_BGR2GRAY);

    GaussianBlur(gray, gray, Size(9, 9), 3, 3);
    //adaptiveThreshold(gray,gray,1,ADAPTIVE_THRESH_MEAN_C,THRESH_BINARY,55,-3);

    double otsu_thresh_val = cv::threshold(
            gray, _img, 0, 255, CV_THRESH_BINARY | CV_THRESH_OTSU
    );

    double high_thresh_val = otsu_thresh_val,
            lower_thresh_val = otsu_thresh_val * 0.33;

    Canny(gray, gray, lower_thresh_val, high_thresh_val);

    morphologyEx(gray, gray, MORPH_CLOSE, getStructuringElement(MORPH_ELLIPSE, Size(10, 10)));

    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;

    findContours(gray, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE, Point(0, 0));

    vector<vector<Point> > contours_poly(contours.size());
    vector<Rect> boundRect(contours.size());

    for (int i = 0; i < contours.size(); i++) {
        approxPolyDP(Mat(contours[i]), contours_poly[i], 3, true);
        boundRect[i] = boundingRect(Mat(contours_poly[i]));
    }

    Scalar color = Scalar(0, 0, 255);

    for (int i = 0; i < contours.size(); i++) {

        drawContours(image, contours_poly, i, color, 2, 8, hierarchy, 0, Point());
        // drawContours(image, contours, i, color, CV_FILLED);
        //rectangle( image, boundRect[i].tl(), boundRect[i].br(), color, 2, 8, 0 );

    }

    imshow("Find Contours", image);

    imwrite("final_result.jpg", image);


    setMouseCallback("Find Contours", onMouse, (void *) &points);

    char key = 0;
    while (key != 27) {


        //for (auto &&point:points)
        for (int count = 0; count < points.size(); count++) {

            for (int i = 0; i < contours.size(); i++) {
                int min_x = boundRect[i].tl().x;
                int min_y = boundRect[i].tl().y;
                int max_x = boundRect[i].br().x;
                int max_y = boundRect[i].br().y;

                for (int j = 0; j < contours[i].size() / 2; j++) {

                    if (points[count].x < max_x && points[count].x > min_x && points[count].y < max_y &&
                        points[count].y > min_y) {

                        drawContours(image, contours, i, color, CV_FILLED);

                    }
                }
            }

        }

        imshow("Find Contours", image);

        key = waitKey(1);
    }

    imwrite("fill.jpg", image);

    return 0;

}
